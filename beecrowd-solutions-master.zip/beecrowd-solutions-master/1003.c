#include <stdio.h>

int main(void)

{
    int a, b, sum;

    scanf("%i %i", &a, &b);

    sum=a+b;

    printf("SOMA = %i\n", sum);

    return 0;
}
