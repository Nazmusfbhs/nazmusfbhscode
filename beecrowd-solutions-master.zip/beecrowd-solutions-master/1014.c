#include <stdio.h>

int main(void)

{
    int x;
    double y, z;

    scanf("%i %lf", &x, &y);

    z=x/y;

    printf("%.3lf km/l\n", z);

    return 0;
}
