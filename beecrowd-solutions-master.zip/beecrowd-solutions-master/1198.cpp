#include <iostream>
#include <cstdlib>
#define ll long long

using namespace std;

int main()
{
    ll int a, b, c;
    while (cin >> a >> b)
    {
        cout << abs(a-b) << endl;
    }
    return 0;
}
