#include <iostream>
#define ull unsigned long long

using namespace std;

int main()
{
    ull int a, b;
    cin >> a >> b;
    cout << ((a+b)*((b-a)+1))/2 << endl;
    return 0;
}
