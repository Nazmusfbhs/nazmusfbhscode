#include <stdio.h>

int main(void)

{
    int a, b, c, d, x;

    scanf("%i %i %i %i", &a, &b, &c, &d);

    x=(a*b)-(c*d);

    printf("DIFERENCA = %i\n", x);

    return 0;
}
