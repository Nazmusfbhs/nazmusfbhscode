#include <stdio.h>

int main(void)

{
    int x, y;

    scanf("%i", &x);

    y=2*x;

    printf("%i minutos\n", y);

    return 0;
}
