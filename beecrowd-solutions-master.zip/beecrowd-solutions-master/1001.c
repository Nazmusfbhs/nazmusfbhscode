#include <stdio.h>

int main(void)

{
    int a, b, x;

    scanf("%i %i", &a, &b);

    x=a+b;

    printf("X = %i\n", x);

    return 0;
}
