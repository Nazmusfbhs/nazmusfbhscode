#include <stdio.h>

int main(void)

{
    int a, b, c, d, total;

    scanf("%i %i %i %i", &a, &b, &c, &d);

    total=(a-1)+(b-1)+(c-1)+d;

    printf("%i\n", total);

    return 0;
}
