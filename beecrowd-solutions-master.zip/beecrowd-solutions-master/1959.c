#include <stdio.h>

int main(void)

{
    long long int a, b, x;

    scanf("%lli %lli", &a, &b);

    x=a*b;

    printf("%lli\n", x);

    return 0;
}
