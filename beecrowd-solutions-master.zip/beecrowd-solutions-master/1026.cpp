#include <iostream>
#define ull unsigned long long

using namespace std;

int main()
{
    ull int a, b;
    while (cin >> a >> b)
    {
        cout << (a^b) << endl;
    }

    return 0;
}
