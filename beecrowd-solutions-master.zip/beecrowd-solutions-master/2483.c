#include <stdio.h>

int main(void)

{
    int i, n;

    scanf("%i", &n);

    printf("Feliz nat");

    for (i=0; i<n; ++i)
        printf("a");

    printf("l!\n");

    return 0;
}
