#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main()
{

}
