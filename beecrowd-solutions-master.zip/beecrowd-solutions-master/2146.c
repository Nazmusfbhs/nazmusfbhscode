#include <stdio.h>

int main(void)

{
    int i, j, n;

    while (scanf("%i", &n) != EOF)
    {
        j=n-1;
        printf("%i\n", j);
    }

    return 0;
}
