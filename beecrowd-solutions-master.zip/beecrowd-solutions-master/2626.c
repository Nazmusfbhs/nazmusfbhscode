#include <stdio.h>
#include <string.h>

int main(void)

{
    int a, b, i, j;
    char s1[10], s2[10], s3[10];

    while (scanf("%s %s %s", s1, s2, s3) != EOF)
    {
        if (strcmp(s1, "papel")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "papel")==0)
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "pedra")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "tesoura")==0))
            printf("Urano perdeu algo muito precioso...\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "papel")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "pedra")==0))
            printf("Os atributos dos monstros vao ser inteligencia, sabedoria...\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "tesoura")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "papel")==0))
            printf("Iron Maiden's gonna get you, no matter how far!\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "pedra")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "papel")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "tesoura")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");



        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "papel")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "pedra")==0))
            printf("Iron Maiden's gonna get you, no matter how far!\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "tesoura")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "papel")==0))
            printf("Urano perdeu algo muito precioso...\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "pedra")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "tesoura")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "papel")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "pedra")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "pedra")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "tesoura")==0))
            printf("Os atributos dos monstros vao ser inteligencia, sabedoria...\n");



        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "papel")==0))
            printf("Os atributos dos monstros vao ser inteligencia, sabedoria...\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "pedra")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "papel")==0 && strcmp(s3, "tesoura")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "papel")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "pedra")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "pedra")==0 && strcmp(s3, "tesoura")==0))
            printf("Iron Maiden's gonna get you, no matter how far!\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "papel")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "pedra")==0))
            printf("Urano perdeu algo muito precioso...\n");

        if ((strcmp(s1, "tesoura")==0 && strcmp(s2, "tesoura")==0 && strcmp(s3, "tesoura")==0))
            printf("Putz vei, o Leo ta demorando muito pra jogar...\n");
    }

    return 0;
}
