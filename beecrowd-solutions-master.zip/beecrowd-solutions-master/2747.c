#include <stdio.h>

int main(void)
{
    int i;

    for (i=0; i<39; ++i)
        printf("-");

    printf("\n");

    printf("|");

    for (i=0; i<37; ++i)
        printf(" ");

    printf("|\n");

    printf("|");

    for (i=0; i<37; ++i)
        printf(" ");

    printf("|\n");

    printf("|");

    for (i=0; i<37; ++i)
        printf(" ");

    printf("|\n");

    printf("|");

    for (i=0; i<37; ++i)
        printf(" ");

    printf("|\n");

    printf("|");

    for (i=0; i<37; ++i)
        printf(" ");

    printf("|\n");

    for (i=0; i<39; ++i)
        printf("-");

    printf("\n");

    return 0;
}
