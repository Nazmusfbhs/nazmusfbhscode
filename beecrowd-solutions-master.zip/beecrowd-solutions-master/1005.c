#include <stdio.h>

int main(void)

{
    double a, b, x;

    scanf("%lf %lf", &a, &b);

    a=a*3.5;
    b=b*7.5;
    x=a+b;
    x=x/11;

    printf("MEDIA = %.5lf\n", x);

    return 0;
}
