#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main()
{
    int n, q, wc, l;
    string s;
    while (cin >> n)
    {
        wc=-1;
        l=0;
        vector<string>v, in, a;
        while (n--)
        {
            cin >> s;
            v.push_back(s);
        }
        cin >> q;
        while (q--)
        {
            cin >> s;

        }
        cout << wc << endl;
        break;
    }
}
