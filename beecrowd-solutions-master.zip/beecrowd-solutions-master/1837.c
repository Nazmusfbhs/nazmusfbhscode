#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a, b, q, r, u, v;



    printf("%i", 5%-3);

    return 0;
}
