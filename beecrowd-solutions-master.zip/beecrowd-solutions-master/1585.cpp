#include <iostream>

using namespace std;

int main()
{
    int t, a, b;
    cin >> t;
    while (t--)
    {
        cin >> a >> b;
        cout << (a*b)/2 << " cm2" << endl;
    }
    return 0;
}
