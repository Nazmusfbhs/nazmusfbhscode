#include <iostream>

using namespace std;

int main()
{
    cout << "\"Ro'b'er\tto\\/\"" << endl;
    cout << "(._.) ( l: ) ( .-. ) ( :l ) (._.)" << endl;
    cout << "(^_-) (-_-) (-_^)" << endl;
    cout << "(\"_\") ('.')" << endl;
    return 0;
}
