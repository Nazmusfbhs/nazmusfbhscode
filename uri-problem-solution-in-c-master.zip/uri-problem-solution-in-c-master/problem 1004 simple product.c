#include <stdio.h>
int main() {
    int A,B,PROD;
	scanf("%d %d",&A,&B);
	PROD=A*B;
	printf("PROD = %d\n",PROD);
    return 0;
}
