#include<stdio.h>
int main(){
    double A,PI=3.14159,R;
    scanf("%lf",&R);
    A=PI*(R*R);
    printf("A=%.4lf\n",A);
    return 0;
}
