#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	printf("%d minutos\n",a*2);
	return 0;
}
