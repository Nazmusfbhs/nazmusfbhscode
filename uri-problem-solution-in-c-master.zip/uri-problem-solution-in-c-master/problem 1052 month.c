#include <stdio.h>
int main()
{
    int x;
    scanf("%d",&x);
    if(x==1)
        printf("January\n");
    else if(x==2)
        printf("February\n");
    else if(x==3)
        printf("March\n");
    else if(x==4)
        printf("April\n");
    else if(x==5)
        printf("May\n");
    else if(x==6)
        printf("June\n");
    else if(x==7)
        printf("July\n");
    else if(x==8)
        printf("August\n");
    else if(x==9)
        printf("September\n");
    else if(x==10)
        printf("October\n");
    else if(x==11)
        printf("November\n");
    else if(x==12)
        printf("December\n");
    return 0;
}
